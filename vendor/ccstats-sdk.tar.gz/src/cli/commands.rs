//! CLI subcommand definitions
//!
//! Defines the available commands for each data source.

use clap::{Subcommand, ValueEnum};

/// Dimension to rank in the `top` command
#[derive(Debug, Clone, Copy, Default, ValueEnum, PartialEq, Eq)]
pub(crate) enum TopDimension {
    /// Rank by model (default)
    #[default]
    Model,
    /// Rank by project (requires source with project capability)
    Project,
}

/// Main CLI commands
#[derive(Subcommand)]
pub(crate) enum Commands {
    /// Check source setup without contacting remote providers
    Doctor,
    /// List available data sources and aliases
    Sources,
    /// Show daily usage (default)
    Daily,
    /// Show weekly usage
    Weekly,
    /// Estimate the current Codex weekly quota pace (Codex-only)
    Quota,
    /// Combined Codex weekly quota and Claude estimated session window
    ///
    /// Prints every honest local limit: Codex weekly quota snapshots and the
    /// current Claude activity-driven 5-hour window. Omit `--source` or use
    /// `--source all` for both; `--source codex` or `--source claude` for one
    /// section. Other sources are not supported.
    Limits,
    /// Show monthly usage
    Monthly,
    /// Show today's usage
    Today,
    /// Show usage by session
    Session,
    /// Show usage by project
    Project,
    /// Show usage by estimated 5-hour session windows
    ///
    /// Windows are inferred from local logs (ccusage-style activity-driven).
    /// This is not an official Anthropic billing reset.
    Blocks,
    /// Show usage split by serving endpoint (native Anthropic vs proxy)
    Endpoints,
    /// Output single line for statusline/tmux integration
    Statusline,
    /// Show tool usage statistics (Read, Bash, Edit, etc.)
    Tools,
    /// Show top N consumers ranked by cost (or tokens when cost is unknown)
    Top {
        /// Dimension to rank by
        #[arg(long, value_enum, default_value_t = TopDimension::Model)]
        dim: TopDimension,
        /// Maximum number of rows to display (1..=1000)
        #[arg(long, default_value_t = 10)]
        limit: usize,
    },
    /// `Codex` CLI usage statistics
    Codex {
        #[command(subcommand)]
        command: Option<CodexCommands>,
    },
    /// Grok CLI usage statistics
    Grok {
        #[command(subcommand)]
        command: Option<GrokCommands>,
    },
    /// Kimi Code CLI usage statistics
    Kimi {
        #[command(subcommand)]
        command: Option<KimiCommands>,
    },
    /// Store local provider credentials
    Login {
        #[command(subcommand)]
        target: LoginTarget,
    },
}

/// Credential wizard targets. Nested under `login` so sources do not grow a
/// fourth CLI grammar (`ccstats cursor …`).
#[derive(Subcommand)]
pub(crate) enum LoginTarget {
    /// Store a Cursor API key or dashboard session token
    Cursor {
        /// Cursor Admin API key (enterprise)
        #[arg(long, value_name = "KEY")]
        api_key: Option<String>,
        /// Dashboard `WorkosCursorSessionToken` cookie
        #[arg(long, value_name = "TOKEN")]
        session_token: Option<String>,
        /// Report whether credentials are configured without printing secrets
        #[arg(long)]
        check: bool,
        /// Remove stored Cursor credentials
        #[arg(long)]
        clear: bool,
        /// Print dashboard URLs without opening a browser
        #[arg(long)]
        no_browser: bool,
    },
}

/// Codex-specific subcommands
#[derive(Subcommand)]
pub(crate) enum CodexCommands {
    /// Show daily Codex usage (default)
    Daily,
    /// Show weekly Codex usage
    Weekly,
    /// Estimate the current Codex weekly quota pace (Codex-only)
    Quota,
    /// Show monthly Codex usage
    Monthly,
    /// Show today's Codex usage
    Today,
    /// Show Codex usage by session
    Session,
    /// Output single line for statusline/tmux integration
    Statusline,
}

/// Grok-specific subcommands
#[derive(Subcommand)]
pub(crate) enum GrokCommands {
    /// Show daily Grok usage (default)
    Daily,
    /// Show weekly Grok usage
    Weekly,
    /// Show monthly Grok usage
    Monthly,
    /// Show today's Grok usage
    Today,
    /// Show Grok usage by session
    Session,
    /// Show Grok usage by project
    Project,
    /// Output single line for statusline/tmux integration
    Statusline,
}

/// Kimi-specific subcommands
#[derive(Subcommand)]
pub(crate) enum KimiCommands {
    /// Show daily Kimi Code usage (default)
    Daily,
    /// Show weekly Kimi Code usage
    Weekly,
    /// Show monthly Kimi Code usage
    Monthly,
    /// Show today's Kimi Code usage
    Today,
    /// Show Kimi Code usage by session
    Session,
    /// Show Kimi Code usage by project
    Project,
    /// Output single line for statusline/tmux integration
    Statusline,
}

/// Normalized command that works across all sources
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum SourceCommand {
    Doctor,
    Sources,
    Daily,
    Weekly,
    Quota,
    Limits,
    Monthly,
    Today,
    Session,
    Project,
    Blocks,
    Endpoints,
    Statusline,
    Tools,
    Top { dim: TopDimension, limit: usize },
}

impl SourceCommand {
    /// Check if this is a statusline command (requires quiet mode)
    pub(crate) fn is_statusline(self) -> bool {
        matches!(self, SourceCommand::Statusline)
    }

    /// Check if this command needs today's date filter
    pub(crate) fn needs_today_filter(self) -> bool {
        matches!(self, SourceCommand::Today | SourceCommand::Statusline)
    }

    /// CLI subcommand token used in user-facing errors.
    pub(crate) fn cli_name(self) -> &'static str {
        match self {
            Self::Doctor => "doctor",
            Self::Sources => "sources",
            Self::Daily => "daily",
            Self::Weekly => "weekly",
            Self::Quota => "quota",
            Self::Limits => "limits",
            Self::Monthly => "monthly",
            Self::Today => "today",
            Self::Session => "session",
            Self::Project => "project",
            Self::Blocks => "blocks",
            Self::Endpoints => "endpoints",
            Self::Statusline => "statusline",
            Self::Tools => "tools",
            Self::Top { .. } => "top",
        }
    }

    pub(crate) fn supports_source_breakdown(self) -> bool {
        matches!(
            self,
            Self::Daily | Self::Weekly | Self::Monthly | Self::Today
        )
    }
}

impl From<&Commands> for SourceCommand {
    #[allow(clippy::match_same_arms)] // Codex default intentionally maps to Daily
    fn from(cmd: &Commands) -> Self {
        match cmd {
            Commands::Doctor => SourceCommand::Doctor,
            Commands::Sources => SourceCommand::Sources,
            Commands::Daily => SourceCommand::Daily,
            Commands::Weekly => SourceCommand::Weekly,
            Commands::Quota => SourceCommand::Quota,
            Commands::Limits => SourceCommand::Limits,
            Commands::Monthly => SourceCommand::Monthly,
            Commands::Today => SourceCommand::Today,
            Commands::Session => SourceCommand::Session,
            Commands::Project => SourceCommand::Project,
            Commands::Blocks => SourceCommand::Blocks,
            Commands::Endpoints => SourceCommand::Endpoints,
            Commands::Statusline => SourceCommand::Statusline,
            Commands::Tools => SourceCommand::Tools,
            Commands::Top { dim, limit } => SourceCommand::Top {
                dim: *dim,
                limit: *limit,
            },
            Commands::Codex { .. }
            | Commands::Grok { .. }
            | Commands::Kimi { .. }
            | Commands::Login { .. } => SourceCommand::Daily, // Default, handled separately
        }
    }
}

impl From<&Option<CodexCommands>> for SourceCommand {
    fn from(cmd: &Option<CodexCommands>) -> Self {
        match cmd {
            Some(CodexCommands::Daily) | None => SourceCommand::Daily,
            Some(CodexCommands::Weekly) => SourceCommand::Weekly,
            Some(CodexCommands::Quota) => SourceCommand::Quota,
            Some(CodexCommands::Monthly) => SourceCommand::Monthly,
            Some(CodexCommands::Today) => SourceCommand::Today,
            Some(CodexCommands::Session) => SourceCommand::Session,
            Some(CodexCommands::Statusline) => SourceCommand::Statusline,
        }
    }
}

impl From<&Option<GrokCommands>> for SourceCommand {
    fn from(cmd: &Option<GrokCommands>) -> Self {
        match cmd {
            Some(GrokCommands::Daily) | None => SourceCommand::Daily,
            Some(GrokCommands::Weekly) => SourceCommand::Weekly,
            Some(GrokCommands::Monthly) => SourceCommand::Monthly,
            Some(GrokCommands::Today) => SourceCommand::Today,
            Some(GrokCommands::Session) => SourceCommand::Session,
            Some(GrokCommands::Project) => SourceCommand::Project,
            Some(GrokCommands::Statusline) => SourceCommand::Statusline,
        }
    }
}

impl From<&Option<KimiCommands>> for SourceCommand {
    fn from(cmd: &Option<KimiCommands>) -> Self {
        match cmd {
            Some(KimiCommands::Daily) | None => SourceCommand::Daily,
            Some(KimiCommands::Weekly) => SourceCommand::Weekly,
            Some(KimiCommands::Monthly) => SourceCommand::Monthly,
            Some(KimiCommands::Today) => SourceCommand::Today,
            Some(KimiCommands::Session) => SourceCommand::Session,
            Some(KimiCommands::Project) => SourceCommand::Project,
            Some(KimiCommands::Statusline) => SourceCommand::Statusline,
        }
    }
}

/// Parsed command with optional source hint from subcommand routing.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct ParsedCommand {
    pub(crate) source_hint: Option<&'static str>,
    pub(crate) command: SourceCommand,
}

/// Parse CLI command into normalized command plus source hint.
pub(crate) fn parse_command(cmd: Option<&Commands>) -> ParsedCommand {
    match cmd {
        Some(Commands::Codex { command }) => ParsedCommand {
            source_hint: Some("codex"),
            command: SourceCommand::from(command),
        },
        Some(Commands::Quota) => ParsedCommand {
            source_hint: Some("codex"),
            command: SourceCommand::Quota,
        },
        Some(Commands::Grok { command }) => ParsedCommand {
            source_hint: Some("grok"),
            command: SourceCommand::from(command),
        },
        Some(Commands::Kimi { command }) => ParsedCommand {
            source_hint: Some("kimi"),
            command: SourceCommand::from(command),
        },
        Some(cmd) => ParsedCommand {
            source_hint: None,
            command: SourceCommand::from(cmd),
        },
        None => ParsedCommand {
            source_hint: None,
            command: SourceCommand::Daily,
        },
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_command_defaults_to_daily_without_source_hint() {
        let parsed = parse_command(None);
        assert_eq!(parsed.command, SourceCommand::Daily);
        assert_eq!(parsed.source_hint, None);
    }

    #[test]
    fn parse_command_codex_sets_source_hint() {
        let parsed = parse_command(Some(&Commands::Codex {
            command: Some(CodexCommands::Session),
        }));
        assert_eq!(parsed.command, SourceCommand::Session);
        assert_eq!(parsed.source_hint, Some("codex"));
    }

    #[test]
    fn parse_command_quota_is_codex_specific() {
        let top_level = parse_command(Some(&Commands::Quota));
        assert_eq!(top_level.command, SourceCommand::Quota);
        assert_eq!(top_level.source_hint, Some("codex"));

        let nested = parse_command(Some(&Commands::Codex {
            command: Some(CodexCommands::Quota),
        }));
        assert_eq!(nested.command, SourceCommand::Quota);
        assert_eq!(nested.source_hint, Some("codex"));
    }

    #[test]
    fn parse_command_limits_has_no_source_hint() {
        let parsed = parse_command(Some(&Commands::Limits));
        assert_eq!(parsed.command, SourceCommand::Limits);
        assert_eq!(parsed.source_hint, None);
    }

    #[test]
    fn parse_command_grok_sets_source_hint() {
        let parsed = parse_command(Some(&Commands::Grok {
            command: Some(GrokCommands::Project),
        }));
        assert_eq!(parsed.command, SourceCommand::Project);
        assert_eq!(parsed.source_hint, Some("grok"));
    }

    #[test]
    fn parse_command_kimi_sets_source_hint() {
        let parsed = parse_command(Some(&Commands::Kimi {
            command: Some(KimiCommands::Project),
        }));
        assert_eq!(parsed.command, SourceCommand::Project);
        assert_eq!(parsed.source_hint, Some("kimi"));
    }

    #[test]
    fn parse_command_regular_keeps_no_source_hint() {
        let parsed = parse_command(Some(&Commands::Weekly));
        assert_eq!(parsed.command, SourceCommand::Weekly);
        assert_eq!(parsed.source_hint, None);
    }

    #[test]
    fn parse_command_sources_has_no_source_hint() {
        let parsed = parse_command(Some(&Commands::Sources));
        assert_eq!(parsed.command, SourceCommand::Sources);
        assert_eq!(parsed.source_hint, None);
    }

    #[test]
    fn parse_command_doctor_has_no_source_hint() {
        let parsed = parse_command(Some(&Commands::Doctor));
        assert_eq!(parsed.command, SourceCommand::Doctor);
        assert_eq!(parsed.source_hint, None);
    }

    #[test]
    fn source_breakdown_supported_only_for_period_views() {
        assert!(SourceCommand::Daily.supports_source_breakdown());
        assert!(SourceCommand::Weekly.supports_source_breakdown());
        assert!(SourceCommand::Monthly.supports_source_breakdown());
        assert!(SourceCommand::Today.supports_source_breakdown());
        assert!(!SourceCommand::Session.supports_source_breakdown());
        assert!(!SourceCommand::Statusline.supports_source_breakdown());
        assert!(
            !SourceCommand::Top {
                dim: TopDimension::Model,
                limit: 10
            }
            .supports_source_breakdown()
        );
        assert_eq!(SourceCommand::Session.cli_name(), "session");
        assert_eq!(SourceCommand::Statusline.cli_name(), "statusline");
        assert_eq!(
            SourceCommand::Top {
                dim: TopDimension::Model,
                limit: 3
            }
            .cli_name(),
            "top"
        );
    }
}
